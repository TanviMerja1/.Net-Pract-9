using System;
using System.Configuration;
using System.Data.SqlClient;

namespace PlacementDashboard
{
    /// <summary>
    /// Creates the PlacementDB database, its tables and sample data on first run (ADO.NET).
    /// </summary>
    public static class DbSetup
    {
        public static void Initialize()
        {
            string cs = ConfigurationManager.ConnectionStrings["PlacementDB"].ConnectionString;

            // 1. Create the database if it does not exist (connect to master first)
            var builder = new SqlConnectionStringBuilder(cs);
            string dbName = builder.InitialCatalog;
            builder.InitialCatalog = "master";

            using (var master = new SqlConnection(builder.ConnectionString))
            {
                master.Open();
                string sql = string.Format("IF DB_ID('{0}') IS NULL CREATE DATABASE [{0}];", dbName);
                using (var cmd = new SqlCommand(sql, master))
                {
                    cmd.ExecuteNonQuery();
                }
            }

            // 2. Create tables + seed data
            using (var con = new SqlConnection(cs))
            {
                con.Open();
                using (var cmd = new SqlCommand(SchemaAndSeed, con))
                {
                    cmd.ExecuteNonQuery();
                }
            }
        }

        private const string SchemaAndSeed = @"
    IF OBJECT_ID('dbo.Students','U') IS NULL
    CREATE TABLE dbo.Students (
        StudentId INT IDENTITY(1,1) PRIMARY KEY,
        Name      NVARCHAR(100) NOT NULL,
        Branch    NVARCHAR(50)  NOT NULL,
        CGPA      DECIMAL(4,2)  NOT NULL CHECK (CGPA BETWEEN 0 AND 10),
        Email     NVARCHAR(100) NOT NULL
    );

    IF OBJECT_ID('dbo.Companies','U') IS NULL
    CREATE TABLE dbo.Companies (
        CompanyId INT IDENTITY(1,1) PRIMARY KEY,
        Name      NVARCHAR(100) NOT NULL UNIQUE,
        Sector    NVARCHAR(50)  NOT NULL,
        Location  NVARCHAR(50)  NOT NULL
    );

    IF OBJECT_ID('dbo.Placements','U') IS NULL
    CREATE TABLE dbo.Placements (
        PlacementId INT IDENTITY(1,1) PRIMARY KEY,
        StudentId   INT NOT NULL UNIQUE REFERENCES dbo.Students(StudentId),
        CompanyId   INT NOT NULL REFERENCES dbo.Companies(CompanyId),
        Role        NVARCHAR(100) NOT NULL,
        PackageLPA  DECIMAL(6,2)  NOT NULL CHECK (PackageLPA >= 0),
        PlacedOn    DATE          NOT NULL
    );

    IF NOT EXISTS (SELECT 1 FROM dbo.Students)
    BEGIN
        INSERT INTO dbo.Students (Name, Branch, CGPA, Email) VALUES
        ('Aarav Patel','CE',8.70,'aarav@example.com'),
        ('Diya Shah','CE',9.10,'diya@example.com'),
        ('Kabir Mehta','CE',7.40,'kabir@example.com'),
        ('Harsh Bhatt','CE',8.40,'harsh@example.com'),
        ('Isha Joshi','IT',8.20,'isha@example.com'),
        ('Rohan Desai','IT',7.90,'rohan@example.com'),
        ('Meera Trivedi','IT',8.80,'meera@example.com'),
        ('Anjali Dave','IT',9.30,'anjali@example.com'),
        ('Yash Parmar','ECE',7.20,'yash@example.com'),
        ('Nisha Vyas','ECE',8.00,'nisha@example.com'),
        ('Karan Solanki','ME',6.90,'karan@example.com'),
        ('Pooja Rana','ME',7.50,'pooja@example.com');

        INSERT INTO dbo.Companies (Name, Sector, Location) VALUES
        ('TCS','IT Services','Ahmedabad'),
        ('Infosys','IT Services','Pune'),
        ('Zydus','Pharma','Ahmedabad'),
        ('L&T','Engineering','Mumbai'),
        ('Amazon','E-Commerce','Bengaluru'),
        ('Adani Group','Infrastructure','Ahmedabad');

        INSERT INTO dbo.Placements (StudentId, CompanyId, Role, PackageLPA, PlacedOn)
        SELECT s.StudentId, c.CompanyId, v.Role, v.Pkg, v.D
        FROM (VALUES
            ('Aarav Patel','TCS','System Engineer',3.60,'2026-02-10'),
            ('Diya Shah','Amazon','SDE-1',24.00,'2026-02-18'),
            ('Isha Joshi','Infosys','Software Engineer',4.00,'2026-02-25'),
            ('Meera Trivedi','Amazon','SDE-1',18.50,'2026-03-02'),
            ('Yash Parmar','L&T','Graduate Engineer Trainee',4.50,'2026-03-09'),
            ('Nisha Vyas','Adani Group','Electrical Engineer',5.20,'2026-03-12'),
            ('Pooja Rana','Zydus','Production Engineer',3.80,'2026-03-20'),
            ('Anjali Dave','Amazon','SDE-1',21.00,'2026-03-25')
        ) v(SName, CName, Role, Pkg, D)
        JOIN dbo.Students s  ON s.Name = v.SName
        JOIN dbo.Companies c ON c.Name = v.CName;
    END";
    }
}
