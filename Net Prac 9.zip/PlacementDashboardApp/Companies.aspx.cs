using System;
using System.Web.UI.WebControls;

namespace PlacementDashboard
{
    /// <summary>Code-behind: shows friendly messages after insert / update / delete.</summary>
    public partial class CompaniesPage : System.Web.UI.Page
    {
        protected void fvCompany_ItemInserted(object sender, FormViewInsertedEventArgs e)
        {
            if (e.Exception != null)
            {
                lblMsg.CssClass = "msg err";
                lblMsg.Text = "Could not add company: " + e.Exception.GetBaseException().Message;
                e.ExceptionHandled = true;
                e.KeepInInsertMode = true;
            }
            else
            {
                lblMsg.Text = "Company added successfully.";
            }
        }

        protected void gvCompanies_RowUpdated(object sender, GridViewUpdatedEventArgs e)
        {
            if (e.Exception != null)
            {
                lblMsg.CssClass = "msg err";
                lblMsg.Text = "Update failed: " + e.Exception.GetBaseException().Message;
                e.ExceptionHandled = true;
                e.KeepInEditMode = true;
            }
            else
            {
                lblMsg.Text = "Company updated successfully.";
            }
        }

        protected void gvCompanies_RowDeleted(object sender, GridViewDeletedEventArgs e)
        {
            if (e.Exception != null)
            {
                lblMsg.CssClass = "msg err";
                lblMsg.Text = "Delete failed (company may have placements): " + e.Exception.GetBaseException().Message;
                e.ExceptionHandled = true;
            }
            else
            {
                lblMsg.Text = "Company deleted successfully.";
            }
        }
    }
}
