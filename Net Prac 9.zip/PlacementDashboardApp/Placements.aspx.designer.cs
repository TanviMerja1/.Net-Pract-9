namespace PlacementDashboard
{
    public partial class PlacementsPage
    {
        protected global::System.Web.UI.WebControls.Label lblMsg;
        protected global::System.Web.UI.WebControls.SqlDataSource dsBranches;
        protected global::System.Web.UI.WebControls.DropDownList ddlBranch;
        protected global::System.Web.UI.WebControls.SqlDataSource dsPlacements;
        protected global::System.Web.UI.WebControls.GridView gvPlacements;
        protected global::System.Web.UI.WebControls.SqlDataSource dsFreeStudents;
        protected global::System.Web.UI.WebControls.SqlDataSource dsAllCompanies;
        protected global::System.Web.UI.WebControls.SqlDataSource dsInsert;
        protected global::System.Web.UI.WebControls.DetailsView dvPlacement;
    }
}
