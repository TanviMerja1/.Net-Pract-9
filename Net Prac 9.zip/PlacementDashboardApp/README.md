# Experiment 9 – Placement Dashboard using Data Controls

ASP.NET Web Forms Web Application (.NET Framework 4.8), runs in Chrome via IIS Express.
Data controls: SqlDataSource, GridView, Repeater, ListView, DetailsView, FormView, DropDownList.

## Run
1. Visual Studio 2022 with the "ASP.NET and web development" workload (includes LocalDB).
2. Double-click PlacementDashboard.sln.
3. Set Chrome: Run-button dropdown -> Browse With... -> Google Chrome -> Set as Default.
4. Press F5 / Ctrl+F5. Database + sample data are created automatically.

## Push to GitHub
git init
git add .
git commit -m "Ex-9 Placement Dashboard"
git branch -M main
git remote add origin <your-repo-url>
git push -u origin main
