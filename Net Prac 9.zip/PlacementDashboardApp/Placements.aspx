<%@ Page Title="Placements" Language="C#" MasterPageFile="~/Site.master" AutoEventWireup="true" CodeBehind="Placements.aspx.cs" Inherits="PlacementDashboard.PlacementsPage" %>

<asp:Content ID="Content1" ContentPlaceHolderID="MainContent" runat="server">

    <h2>Placement Records</h2>
    <asp:Label ID="lblMsg" runat="server" CssClass="msg" EnableViewState="false" />

    <%-- Branch filter (DropDownList bound to a data source) --%>
    <asp:SqlDataSource ID="dsBranches" runat="server"
        ConnectionString="<%$ ConnectionStrings:PlacementDB %>"
        SelectCommand="SELECT DISTINCT Branch FROM Students ORDER BY Branch">
    </asp:SqlDataSource>

    <p>
        Filter by branch:
        <asp:DropDownList ID="ddlBranch" runat="server" DataSourceID="dsBranches"
            DataTextField="Branch" DataValueField="Branch" AppendDataBoundItems="True" AutoPostBack="True">
            <asp:ListItem Value="" Text="All Branches" />
        </asp:DropDownList>
    </p>

    <asp:SqlDataSource ID="dsPlacements" runat="server"
        ConnectionString="<%$ ConnectionStrings:PlacementDB %>"
        SelectCommand="SELECT p.PlacementId, s.Name AS Student, s.Branch, c.Name AS Company, p.Role, p.PackageLPA, p.PlacedOn
                       FROM Placements p
                       JOIN Students s  ON s.StudentId = p.StudentId
                       JOIN Companies c ON c.CompanyId = p.CompanyId
                       WHERE (@Branch = '' OR s.Branch = @Branch)
                       ORDER BY p.PlacedOn DESC"
        DeleteCommand="DELETE FROM Placements WHERE PlacementId=@PlacementId">
        <SelectParameters>
            <asp:ControlParameter Name="Branch" ControlID="ddlBranch" PropertyName="SelectedValue"
                Type="String" DefaultValue="" ConvertEmptyStringToNull="False" />
        </SelectParameters>
    </asp:SqlDataSource>

    <asp:GridView ID="gvPlacements" runat="server" DataSourceID="dsPlacements" DataKeyNames="PlacementId"
        AutoGenerateColumns="False" AllowPaging="True" PageSize="8" AllowSorting="True"
        CssClass="grid" GridLines="None" OnRowDeleted="gvPlacements_RowDeleted"
        EmptyDataText="No placement records found.">
        <PagerStyle CssClass="pager" />
        <Columns>
            <asp:BoundField DataField="PlacementId" HeaderText="ID" ReadOnly="True" SortExpression="PlacementId" />
            <asp:BoundField DataField="Student" HeaderText="Student" SortExpression="Student" />
            <asp:BoundField DataField="Branch" HeaderText="Branch" SortExpression="Branch" />
            <asp:BoundField DataField="Company" HeaderText="Company" SortExpression="Company" />
            <asp:BoundField DataField="Role" HeaderText="Role" SortExpression="Role" />
            <asp:BoundField DataField="PackageLPA" HeaderText="Package (LPA)" SortExpression="PackageLPA" DataFormatString="{0:F2}" />
            <asp:BoundField DataField="PlacedOn" HeaderText="Placed On" SortExpression="PlacedOn" DataFormatString="{0:dd-MM-yyyy}" />
            <asp:CommandField ShowDeleteButton="True" DeleteText="Remove" />
        </Columns>
    </asp:GridView>

    <h2>Record a New Placement</h2>

    <asp:SqlDataSource ID="dsFreeStudents" runat="server"
        ConnectionString="<%$ ConnectionStrings:PlacementDB %>"
        SelectCommand="SELECT StudentId, Name + ' (' + Branch + ')' AS Display FROM Students
                       WHERE StudentId NOT IN (SELECT StudentId FROM Placements) ORDER BY Name">
    </asp:SqlDataSource>

    <asp:SqlDataSource ID="dsAllCompanies" runat="server"
        ConnectionString="<%$ ConnectionStrings:PlacementDB %>"
        SelectCommand="SELECT CompanyId, Name FROM Companies ORDER BY Name">
    </asp:SqlDataSource>

    <asp:SqlDataSource ID="dsInsert" runat="server"
        ConnectionString="<%$ ConnectionStrings:PlacementDB %>"
        SelectCommand="SELECT PlacementId, StudentId, CompanyId, Role, PackageLPA, PlacedOn FROM Placements"
        InsertCommand="INSERT INTO Placements (StudentId, CompanyId, Role, PackageLPA, PlacedOn) VALUES (@StudentId, @CompanyId, @Role, @PackageLPA, @PlacedOn)">
    </asp:SqlDataSource>

    <asp:DetailsView ID="dvPlacement" runat="server" DataSourceID="dsInsert" DefaultMode="Insert"
        AutoGenerateRows="False" CssClass="grid" GridLines="None" Width="500px"
        OnItemInserted="dvPlacement_ItemInserted">
        <Fields>
            <asp:TemplateField HeaderText="Student">
                <InsertItemTemplate>
                    <asp:DropDownList ID="ddlStudent" runat="server" DataSourceID="dsFreeStudents"
                        DataTextField="Display" DataValueField="StudentId" SelectedValue='<%# Bind("StudentId") %>' />
                </InsertItemTemplate>
            </asp:TemplateField>
            <asp:TemplateField HeaderText="Company">
                <InsertItemTemplate>
                    <asp:DropDownList ID="ddlCompany" runat="server" DataSourceID="dsAllCompanies"
                        DataTextField="Name" DataValueField="CompanyId" SelectedValue='<%# Bind("CompanyId") %>' />
                </InsertItemTemplate>
            </asp:TemplateField>
            <asp:BoundField DataField="Role" HeaderText="Role" />
            <asp:BoundField DataField="PackageLPA" HeaderText="Package (LPA)" />
            <asp:BoundField DataField="PlacedOn" HeaderText="Placed On (yyyy-mm-dd)" />
            <asp:CommandField ShowInsertButton="True" ShowCancelButton="False" InsertText="Save Placement" />
        </Fields>
    </asp:DetailsView>

</asp:Content>
