namespace PlacementDashboard
{
    public partial class StudentsPage
    {
        protected global::System.Web.UI.WebControls.Label lblMsg;
        protected global::System.Web.UI.WebControls.SqlDataSource dsStudents;
        protected global::System.Web.UI.WebControls.GridView gvStudents;
        protected global::System.Web.UI.WebControls.DetailsView dvStudent;
    }
}
