namespace PlacementDashboard
{
    public partial class CompaniesPage
    {
        protected global::System.Web.UI.WebControls.Label lblMsg;
        protected global::System.Web.UI.WebControls.SqlDataSource dsCompanies;
        protected global::System.Web.UI.WebControls.GridView gvCompanies;
        protected global::System.Web.UI.WebControls.FormView fvCompany;
    }
}
