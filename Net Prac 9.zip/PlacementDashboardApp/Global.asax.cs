using System;

namespace PlacementDashboard
{
    public class Global : System.Web.HttpApplication
    {
        // Runs once when the site starts: creates the database, tables and sample data.
        protected void Application_Start(object sender, EventArgs e)
        {
            DbSetup.Initialize();
        }
    }
}
