<%@ Page Title="Dashboard" Language="C#" MasterPageFile="~/Site.master" %>

<asp:Content ID="Content1" ContentPlaceHolderID="MainContent" runat="server">

    <h2>Placement Overview</h2>

    <%-- DATA CONTROL 1: Repeater - summary cards --%>
    <asp:SqlDataSource ID="dsStats" runat="server"
        ConnectionString="<%$ ConnectionStrings:PlacementDB %>"
        SelectCommand="SELECT 'Total Students' AS Metric, CAST(COUNT(*) AS VARCHAR(30)) AS Value FROM Students
            UNION ALL SELECT 'Students Placed', CAST(COUNT(*) AS VARCHAR(30)) FROM Placements
            UNION ALL SELECT 'Placement %', ISNULL(CAST(CAST(100.0 * (SELECT COUNT(*) FROM Placements) / NULLIF((SELECT COUNT(*) FROM Students), 0) AS DECIMAL(5,1)) AS VARCHAR(30)), '0') + '%' 
            UNION ALL SELECT 'Highest Package (LPA)', ISNULL(CAST(MAX(PackageLPA) AS VARCHAR(30)), '0') FROM Placements
            UNION ALL SELECT 'Average Package (LPA)', ISNULL(CAST(CAST(AVG(PackageLPA) AS DECIMAL(6,2)) AS VARCHAR(30)), '0') FROM Placements
            UNION ALL SELECT 'Companies Visited', CAST(COUNT(*) AS VARCHAR(30)) FROM Companies">
    </asp:SqlDataSource>

    <asp:Repeater ID="rptStats" runat="server" DataSourceID="dsStats">
        <HeaderTemplate><div class="cards"></HeaderTemplate>
        <ItemTemplate>
            <div class="card">
                <div class="val"><%# Eval("Value") %></div>
                <div class="lbl"><%# Eval("Metric") %></div>
            </div>
        </ItemTemplate>
        <FooterTemplate></div></FooterTemplate>
    </asp:Repeater>

    <h2>Branch-wise Placement</h2>

    <%-- DATA CONTROL 2: Repeater - progress bars --%>
    <asp:SqlDataSource ID="dsBranch" runat="server"
        ConnectionString="<%$ ConnectionStrings:PlacementDB %>"
        SelectCommand="SELECT s.Branch, COUNT(*) AS Total, COUNT(p.PlacementId) AS Placed,
                       CAST(100.0 * COUNT(p.PlacementId) / COUNT(*) AS DECIMAL(5,1)) AS Pct
                       FROM Students s LEFT JOIN Placements p ON p.StudentId = s.StudentId
                       GROUP BY s.Branch ORDER BY s.Branch">
    </asp:SqlDataSource>

    <div class="panel">
        <asp:Repeater ID="rptBranch" runat="server" DataSourceID="dsBranch">
            <ItemTemplate>
                <div class="bar-row">
                    <div class="bar-label"><%# Eval("Branch") %></div>
                    <div class="bar-bg"><div class="bar-fill" style='width:<%# Convert.ToInt32(Eval("Pct")) %>%'></div></div>
                    <div class="bar-text"><%# Eval("Placed") %> / <%# Eval("Total") %> placed (<%# Eval("Pct") %>%)</div>
                </div>
            </ItemTemplate>
        </asp:Repeater>
    </div>

    <div class="two">
        <div>
            <h2>Top 5 Packages</h2>

            <%-- DATA CONTROL 3: ListView --%>
            <asp:SqlDataSource ID="dsTop" runat="server"
                ConnectionString="<%$ ConnectionStrings:PlacementDB %>"
                SelectCommand="SELECT TOP 5 s.Name AS Student, s.Branch, c.Name AS Company, p.Role, p.PackageLPA
                               FROM Placements p
                               JOIN Students s  ON s.StudentId = p.StudentId
                               JOIN Companies c ON c.CompanyId = p.CompanyId
                               ORDER BY p.PackageLPA DESC">
            </asp:SqlDataSource>

            <asp:ListView ID="lvTop" runat="server" DataSourceID="dsTop">
                <LayoutTemplate>
                    <table class="grid">
                        <tr><th>Student</th><th>Branch</th><th>Company</th><th>LPA</th></tr>
                        <asp:PlaceHolder ID="itemPlaceholder" runat="server" />
                    </table>
                </LayoutTemplate>
                <ItemTemplate>
                    <tr>
                        <td><%# Eval("Student") %></td>
                        <td><%# Eval("Branch") %></td>
                        <td><%# Eval("Company") %></td>
                        <td><b><%# Eval("PackageLPA", "{0:F2}") %></b></td>
                    </tr>
                </ItemTemplate>
                <EmptyDataTemplate><p>No placements yet.</p></EmptyDataTemplate>
            </asp:ListView>
        </div>

        <div>
            <h2>Company-wise Hiring</h2>

            <%-- DATA CONTROL 4: GridView (sortable) --%>
            <asp:SqlDataSource ID="dsCompany" runat="server"
                ConnectionString="<%$ ConnectionStrings:PlacementDB %>"
                SelectCommand="SELECT c.Name AS Company, c.Sector, COUNT(p.PlacementId) AS Hires,
                               ISNULL(MAX(p.PackageLPA), 0) AS MaxPackage,
                               ISNULL(CAST(AVG(p.PackageLPA) AS DECIMAL(6,2)), 0) AS AvgPackage
                               FROM Companies c LEFT JOIN Placements p ON p.CompanyId = c.CompanyId
                               GROUP BY c.Name, c.Sector">
            </asp:SqlDataSource>

            <asp:GridView ID="gvCompany" runat="server" DataSourceID="dsCompany" AutoGenerateColumns="False"
                AllowSorting="True" CssClass="grid" GridLines="None">
                <Columns>
                    <asp:BoundField DataField="Company" HeaderText="Company" SortExpression="Company" />
                    <asp:BoundField DataField="Sector" HeaderText="Sector" SortExpression="Sector" />
                    <asp:BoundField DataField="Hires" HeaderText="Hires" SortExpression="Hires" />
                    <asp:BoundField DataField="MaxPackage" HeaderText="Max LPA" SortExpression="MaxPackage" DataFormatString="{0:F2}" />
                    <asp:BoundField DataField="AvgPackage" HeaderText="Avg LPA" SortExpression="AvgPackage" DataFormatString="{0:F2}" />
                </Columns>
            </asp:GridView>
        </div>
    </div>

    <h2>Recent Placements</h2>

    <%-- DATA CONTROL 5: GridView with paging --%>
    <asp:SqlDataSource ID="dsRecent" runat="server"
        ConnectionString="<%$ ConnectionStrings:PlacementDB %>"
        SelectCommand="SELECT s.Name AS Student, s.Branch, c.Name AS Company, p.Role, p.PackageLPA, p.PlacedOn
                       FROM Placements p
                       JOIN Students s  ON s.StudentId = p.StudentId
                       JOIN Companies c ON c.CompanyId = p.CompanyId
                       ORDER BY p.PlacedOn DESC">
    </asp:SqlDataSource>

    <asp:GridView ID="gvRecent" runat="server" DataSourceID="dsRecent" AutoGenerateColumns="False"
        AllowPaging="True" PageSize="5" CssClass="grid" GridLines="None">
        <PagerStyle CssClass="pager" />
        <Columns>
            <asp:BoundField DataField="Student" HeaderText="Student" />
            <asp:BoundField DataField="Branch" HeaderText="Branch" />
            <asp:BoundField DataField="Company" HeaderText="Company" />
            <asp:BoundField DataField="Role" HeaderText="Role" />
            <asp:BoundField DataField="PackageLPA" HeaderText="Package (LPA)" DataFormatString="{0:F2}" />
            <asp:BoundField DataField="PlacedOn" HeaderText="Placed On" DataFormatString="{0:dd-MM-yyyy}" />
        </Columns>
    </asp:GridView>

</asp:Content>
