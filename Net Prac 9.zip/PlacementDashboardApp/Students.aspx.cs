using System;
using System.Web.UI.WebControls;

namespace PlacementDashboard
{
    /// <summary>Code-behind: shows friendly messages after insert / update / delete.</summary>
    public partial class StudentsPage : System.Web.UI.Page
    {
        protected void dvStudent_ItemInserted(object sender, DetailsViewInsertedEventArgs e)
        {
            if (e.Exception != null)
            {
                lblMsg.CssClass = "msg err";
                lblMsg.Text = "Could not add student: " + e.Exception.GetBaseException().Message;
                e.ExceptionHandled = true;
                e.KeepInInsertMode = true;
            }
            else
            {
                lblMsg.Text = "Student added successfully.";
            }
        }

        protected void gvStudents_RowUpdated(object sender, GridViewUpdatedEventArgs e)
        {
            if (e.Exception != null)
            {
                lblMsg.CssClass = "msg err";
                lblMsg.Text = "Update failed: " + e.Exception.GetBaseException().Message;
                e.ExceptionHandled = true;
                e.KeepInEditMode = true;
            }
            else
            {
                lblMsg.Text = "Student updated successfully.";
            }
        }

        protected void gvStudents_RowDeleted(object sender, GridViewDeletedEventArgs e)
        {
            if (e.Exception != null)
            {
                lblMsg.CssClass = "msg err";
                lblMsg.Text = "Delete failed (student may already have a placement): " + e.Exception.GetBaseException().Message;
                e.ExceptionHandled = true;
            }
            else
            {
                lblMsg.Text = "Student deleted successfully.";
            }
        }
    }
}
