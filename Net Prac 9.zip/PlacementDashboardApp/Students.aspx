<%@ Page Title="Students" Language="C#" MasterPageFile="~/Site.master" AutoEventWireup="true" CodeBehind="Students.aspx.cs" Inherits="PlacementDashboard.StudentsPage" %>

<asp:Content ID="Content1" ContentPlaceHolderID="MainContent" runat="server">

    <h2>Manage Students</h2>
    <asp:Label ID="lblMsg" runat="server" CssClass="msg" EnableViewState="false" />

    <%-- One data source supports Select / Insert / Update / Delete --%>
    <asp:SqlDataSource ID="dsStudents" runat="server"
        ConnectionString="<%$ ConnectionStrings:PlacementDB %>"
        SelectCommand="SELECT StudentId, Name, Branch, CGPA, Email FROM Students ORDER BY StudentId"
        InsertCommand="INSERT INTO Students (Name, Branch, CGPA, Email) VALUES (@Name, @Branch, @CGPA, @Email)"
        UpdateCommand="UPDATE Students SET Name=@Name, Branch=@Branch, CGPA=@CGPA, Email=@Email WHERE StudentId=@StudentId"
        DeleteCommand="DELETE FROM Students WHERE StudentId=@StudentId">
    </asp:SqlDataSource>

    <%-- GridView: list, sort, page, edit, delete --%>
    <asp:GridView ID="gvStudents" runat="server" DataSourceID="dsStudents" DataKeyNames="StudentId"
        AutoGenerateColumns="False" AllowPaging="True" PageSize="8" AllowSorting="True"
        CssClass="grid" GridLines="None"
        OnRowUpdated="gvStudents_RowUpdated" OnRowDeleted="gvStudents_RowDeleted">
        <PagerStyle CssClass="pager" />
        <Columns>
            <asp:BoundField DataField="StudentId" HeaderText="ID" ReadOnly="True" SortExpression="StudentId" />
            <asp:BoundField DataField="Name" HeaderText="Name" SortExpression="Name" />
            <asp:BoundField DataField="Branch" HeaderText="Branch" SortExpression="Branch" />
            <asp:BoundField DataField="CGPA" HeaderText="CGPA" SortExpression="CGPA" />
            <asp:BoundField DataField="Email" HeaderText="Email" SortExpression="Email" />
            <asp:CommandField ShowEditButton="True" ShowDeleteButton="True" />
        </Columns>
    </asp:GridView>

    <h2>Add New Student</h2>

    <%-- DetailsView: insert a new record --%>
    <asp:DetailsView ID="dvStudent" runat="server" DataSourceID="dsStudents" DefaultMode="Insert"
        AutoGenerateRows="False" CssClass="grid" GridLines="None" Width="450px"
        OnItemInserted="dvStudent_ItemInserted">
        <Fields>
            <asp:BoundField DataField="Name" HeaderText="Name" />
            <asp:BoundField DataField="Branch" HeaderText="Branch (CE/IT/ECE/ME)" />
            <asp:BoundField DataField="CGPA" HeaderText="CGPA (0-10)" />
            <asp:BoundField DataField="Email" HeaderText="Email" />
            <asp:CommandField ShowInsertButton="True" ShowCancelButton="False" InsertText="Add Student" />
        </Fields>
    </asp:DetailsView>

</asp:Content>
