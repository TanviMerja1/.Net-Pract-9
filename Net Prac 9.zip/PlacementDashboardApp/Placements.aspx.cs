using System;
using System.Web.UI.WebControls;

namespace PlacementDashboard
{
    /// <summary>Code-behind: refreshes the grid and shows messages after insert / delete.</summary>
    public partial class PlacementsPage : System.Web.UI.Page
    {
        protected void dvPlacement_ItemInserted(object sender, DetailsViewInsertedEventArgs e)
        {
            if (e.Exception != null)
            {
                lblMsg.CssClass = "msg err";
                lblMsg.Text = "Could not save placement: " + e.Exception.GetBaseException().Message;
                e.ExceptionHandled = true;
                e.KeepInInsertMode = true;
            }
            else
            {
                lblMsg.Text = "Placement recorded successfully.";
                gvPlacements.DataBind();   // refresh the list
            }
        }

        protected void gvPlacements_RowDeleted(object sender, GridViewDeletedEventArgs e)
        {
            if (e.Exception != null)
            {
                lblMsg.CssClass = "msg err";
                lblMsg.Text = "Delete failed: " + e.Exception.GetBaseException().Message;
                e.ExceptionHandled = true;
            }
            else
            {
                lblMsg.Text = "Placement removed.";
            }
        }
    }
}
