<%@ Page Title="Companies" Language="C#" MasterPageFile="~/Site.master" AutoEventWireup="true" CodeBehind="Companies.aspx.cs" Inherits="PlacementDashboard.CompaniesPage" %>

<asp:Content ID="Content1" ContentPlaceHolderID="MainContent" runat="server">

    <h2>Manage Companies</h2>
    <asp:Label ID="lblMsg" runat="server" CssClass="msg" EnableViewState="false" />

    <asp:SqlDataSource ID="dsCompanies" runat="server"
        ConnectionString="<%$ ConnectionStrings:PlacementDB %>"
        SelectCommand="SELECT CompanyId, Name, Sector, Location FROM Companies ORDER BY CompanyId"
        InsertCommand="INSERT INTO Companies (Name, Sector, Location) VALUES (@Name, @Sector, @Location)"
        UpdateCommand="UPDATE Companies SET Name=@Name, Sector=@Sector, Location=@Location WHERE CompanyId=@CompanyId"
        DeleteCommand="DELETE FROM Companies WHERE CompanyId=@CompanyId">
    </asp:SqlDataSource>

    <asp:GridView ID="gvCompanies" runat="server" DataSourceID="dsCompanies" DataKeyNames="CompanyId"
        AutoGenerateColumns="False" AllowPaging="True" PageSize="8" AllowSorting="True"
        CssClass="grid" GridLines="None"
        OnRowUpdated="gvCompanies_RowUpdated" OnRowDeleted="gvCompanies_RowDeleted">
        <PagerStyle CssClass="pager" />
        <Columns>
            <asp:BoundField DataField="CompanyId" HeaderText="ID" ReadOnly="True" SortExpression="CompanyId" />
            <asp:BoundField DataField="Name" HeaderText="Company" SortExpression="Name" />
            <asp:BoundField DataField="Sector" HeaderText="Sector" SortExpression="Sector" />
            <asp:BoundField DataField="Location" HeaderText="Location" SortExpression="Location" />
            <asp:CommandField ShowEditButton="True" ShowDeleteButton="True" />
        </Columns>
    </asp:GridView>

    <h2>Add New Company</h2>

    <%-- FormView: insert template --%>
    <asp:FormView ID="fvCompany" runat="server" DataSourceID="dsCompanies" DefaultMode="Insert"
        OnItemInserted="fvCompany_ItemInserted">
        <InsertItemTemplate>
            <div class="panel">
                <p>Name: <asp:TextBox ID="txtName" runat="server" Text='<%# Bind("Name") %>' /></p>
                <p>Sector: <asp:TextBox ID="txtSector" runat="server" Text='<%# Bind("Sector") %>' /></p>
                <p>Location: <asp:TextBox ID="txtLocation" runat="server" Text='<%# Bind("Location") %>' /></p>
                <asp:Button ID="btnInsert" runat="server" CommandName="Insert" Text="Add Company" />
            </div>
        </InsertItemTemplate>
    </asp:FormView>

</asp:Content>
